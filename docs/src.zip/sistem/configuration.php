<?php
/* FILE : configuration.php */
define('NameUser','ROBUSA_USER');
define('IDUser','ROBUSA_ID');

$sas['mysql']['database'] = 'tugas_wbd1';
$sas['mysql']['host'] = 'localhost';
$sas['mysql']['username'] = 'wbd_user1';
$sas['mysql']['password'] = 'wbd@if3110';

$sas['setting']['construction'] = false;
$sas['setting']['c_login_active'] = 30 * 24 * 60 * 60;
$sas['setting']['static_salt'] = "u8C#2m";
?>