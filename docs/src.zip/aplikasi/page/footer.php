    </article>
    <div style="height: 10px; background-color: #B0B0B0"></div>
    <footer class="container">
        <div>Ruserba &copy; 2013</div>
    </footer>
    <script src="<?php print HOME_URL; ?>assets/use.js"></script>
    <script src="<?php print HOME_URL; ?>assets/validator.js"></script>
</body>
</html>