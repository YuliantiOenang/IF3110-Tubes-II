<h1>Profil Pelanggan</h1>
<div id="identitas" onLoad="getMoreIdentity()">
    <p><input type="button" name="load" onClick="getMoreIdentity()" value="Lihat profil"></p>
</div>