<div id="core">
<?php
	require('header.php');
?>
<div id="content">
