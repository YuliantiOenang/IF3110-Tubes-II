	<?php include_once('core_end.php'); ?>
</body>
</html>
