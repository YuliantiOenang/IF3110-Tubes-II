<div id="footer">
<p>Copyright &copy; <?php echo date("Y"); ?> RuSerBa. All rights reserved.</p>
</div>