Langkah-langkah Instalasi:
- Buat database "ruserba" pada MySQL.
- Lakukan source pada file database dump "ruserba.sql".
- Ubah properti username/password dari database pada "db.sql" jika diperlukan.
- Lakukan instalasi sistem pada folder src/ ke server (lokal).
