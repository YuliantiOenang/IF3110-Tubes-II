/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package koneksi;
/**
 *
 * @author octo
 */
public class WebUtil {
   public static boolean isEmail(String email)
 {
  if(email==null)
  {
   return false;
  }
  //Assigning the email format regular expression
  String emailPattern="^([A-Za-z0-9_\\-\\.])+\\@([A-Za-z0-9_\\-\\.])+\\.([A-Za-z]{2,4})";
  return email.matches(emailPattern); 
 }
 
 /**
  * Checks whether the given URL (website address) is valid.
  * @param url represents the website address.
  * @return true if the email is valid, false otherwise.
  * @since 09-Feb-2009
  */
 public static boolean isURL(String url)
 {
  if(url==null)
  {
   return false;
  }
  //Assigning the url format regular expression
  String urlPattern="^http(s{0,1})://[a-zA-Z0-9_/\\-\\.]+\\.([A-Za-z/]{2,5})[a-zA-Z0-9_/\\&\\?\\=\\-\\.\\~\\%]*";
  return url.matches(urlPattern); 
 }
}
