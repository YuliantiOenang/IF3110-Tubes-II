/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package koneksi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JOptionPane;

/**
 *
 * @author putrandi
 */
public class koneksi {
    public Connection con;
    public Statement stat;
    public void dbopen() throws SQLException
    {
        try
        {
         Class.forName("com.mysql.jdbc.Driver");
         con = DriverManager.getConnection("jdbc:mysql://localhost/alat_pesta", "root", "");
         stat = con.createStatement();
        }
        catch( ClassNotFoundException ex)
                {
                    JOptionPane.showMessageDialog(null, ex, "Error",JOptionPane.ERROR_MESSAGE);
                }
        catch(SQLException e)
        {
            JOptionPane.showMessageDialog(null, e, "Error",JOptionPane.ERROR_MESSAGE);
        }
    }
}
