<?php
	$sql=mysql_connect("localhost","root","");
	$db=mysql_select_db("alat_pesta");
	
	/* if ($db)
		echo "sukses";
	else
		echo "gagal";  */
?>